default_app_config = 'apps.faculty.apps.FacultyConfig'
