default_app_config = 'apps.core.apps.CoreConfig'
