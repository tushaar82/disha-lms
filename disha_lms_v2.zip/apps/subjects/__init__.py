default_app_config = 'apps.subjects.apps.SubjectsConfig'
