default_app_config = 'apps.attendance.apps.AttendanceConfig'
